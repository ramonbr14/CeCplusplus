#include <stdlib.h>
#include <stdio.h>
       
typedef struct{
        float p1;
        float p2;
        }numComp;
 
numComplex a(float p1, float p2);

nunComplex b(float p1, float p2); 

numComplex I(float p1, float p2);

