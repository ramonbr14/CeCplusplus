#include <stdio.h>
#include "NumComplex.h"


float Adicao(numComplex a(float p1, float p2),numComplex b(float p1, float p2)){
      float z1 = numComplex.a(p1)+numComplex.b(p1)
      float z2 = numComplex.a(p2)+numComplex.b(p2)             
      return z1;
      return z2;
      }

float Adicao(numComplex a(float p1, float p2),numComplex b(float p1, float p2)){
      float z1 = numComplex.a(p1)+numComplex.b(p1)
      float z2 = numComplex.a(p2)+numComplex.b(p2)             
      return m1;
      return z2;
      }

