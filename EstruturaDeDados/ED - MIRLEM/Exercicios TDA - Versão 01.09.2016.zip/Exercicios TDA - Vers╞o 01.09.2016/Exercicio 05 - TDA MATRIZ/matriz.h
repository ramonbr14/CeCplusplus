#include <stdlib.h>
#include <stdio.h>
#define L 2
#define C 2

int k,i;
int matrizA[L][C];
int matrizB[L][C];
int matrizRS[L][C];
int matrizRM[L][C];
int matrizARI[L][C];
int matrizBRI[L][C];
int ii = L;
int kk = C;

void prencherMT();
void somaMT();
void multMT();
void inveMT();
void ImpSoma();
void ImpMult();
void ImpInver();
