#include <stdio.h>
#include <stdlib.h>
#include "matriz.c"

int main (void){
	
	prencherMT();
	somaMT();
	multMT();
	inveMT();
	ImpSoma();
	ImpMult();
	ImpInver();
}
//"2016118970019 - RAMON DOS SANTOS SILVA - TADS";
//Implementado, mas com erros no resultado final!
