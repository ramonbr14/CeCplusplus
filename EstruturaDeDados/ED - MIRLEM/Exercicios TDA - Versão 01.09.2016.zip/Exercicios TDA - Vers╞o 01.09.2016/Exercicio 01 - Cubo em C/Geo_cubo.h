#include <stdio.h>
#include <stdlib.h>

float vol_cubo(float base, float largura, float altura);

float area_cubo(float base, float largura, float altura);
