#include <stdio.h>
#include <stdlib.h>
#define k 3
//int v = ;
int vetorTDA[k];

void preenchendoVETOR();
int SomaVETOR();
int maiorVETOR();
int mediaVETOR(int resultS);
