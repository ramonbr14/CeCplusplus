//Listainear SLIDE
#include <stdlib.h>
#include <stdio.h>
#define valor 5

float L1[valor];
float L2[valor];
float L3[valor+valor];
int i,c,t,p;

void preencherL();
void implistas();
void ordenada();
void copiada();
void copiadaS();
void invertTOL2();
void invert();
void intecale();
void excluirEle();
