

struct relatorios {
	
	char assunto[30];
};

void MovimentoRelatorios(){
	//consultas cons;
	relatorios relat;
	
	int a = 0;
	
	DIR *dir;
	struct dirent *lsdir;
	fflush(stdin);
	
	system("cls");
	FundodeTela();
	gotoxy(3,6);
	cout << "1- GASTOS DE CADA CLIENTE";//6
	gotoxy(3,8);
	cout << "2- RELACAO DE FITAS ALUGADAS MAIS DE UMA VEZ DE CADA CLIENTE";//8
	gotoxy(3,10);
	cout << "3- RELATORIO DE FITAS POR ASSUNTO";//10
	gotoxy(3,12);
	cout << "4- RELATORIO DE FITAS PREMIADAS COM UM OSCAR";//10
	gotoxy(3,14);
	cout << "5- ENCERRAR/FECHAR";//12
	gotoxy(1,25);
	cin >> sop;
	
	fflush(stdin);
	system("cls");
	FundodeTela();
	gotoxy(3, 6);
				
	switch(sop){
		case 1: {
		
		
		
			break;
		}
		case 2:{
			
		
			break;
		}
		case 3:{
			printf("DIGITE O ASSUNTO PARA O RELATORIO:");
			gets(relat.assunto);

	    	dir = opendir("fitas/");
	    	printf("\n");
	    	while ( ( lsdir = readdir(dir) ) != NULL) {
		  	 	if( (strcmp(lsdir->d_name, "..") == 1))  {
		   			sprintf(jStr, "fitas/%s", lsdir->d_name);
		   			
					if(!strcmp(relat.assunto, jGetString(jStr, "assunto"))){	
						char jStr2[30] = "";
						gotoxy(3,8+a);
						printf("Filme: %s", jGetString(jStr, "titulo"));
						a++;
					}
				}
			}
			printf("\n\n");
    		closedir(dir);
    		system("pause");
    		 					
			break;
		}
		case 4:{
			
	    	dir = opendir("fitas/");
	    	printf("\n");
	    	while ( ( lsdir = readdir(dir) ) != NULL) {
		  	 	if( (strcmp(lsdir->d_name, "..") == 1))  {
		   			sprintf(jStr, "fitas/%s", lsdir->d_name);
		   			
					if(jGetInt(jStr, "oscar") == 1){	
						char jStr2[30] = "";
						gotoxy(3,8+a);
						printf("Filme: %s", jGetString(jStr, "titulo"));
						a++;
					}
				}
			}
    		closedir(dir);
    		system("pause");
			break;
		}
		default:{
			system("pause");
			break;
		}
	}
}

