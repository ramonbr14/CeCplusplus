#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include "LDE.H"


lRM* lcriar (void){
	return NULL;
};

lRM* finsercao (lRM* liRM, int i){
	lRM* nEle = (lRM*) malloc(sizeof(liRM));
	nEle->inf = i;
	nEle->prx = liRM;
	return nEle;	
};

void imprimirLDE(lRM* liRM){
	lRM* t;
	printf("Teste 1");
	while(t->prx != NULL){
		printf("Teste 2");
		printf("Lista = %d", t->inf);
		t = t->prx;
		//cout << "LISTA DINAMICAMENTE ENCADEADA: "<< t->inf;
	}
		
}
