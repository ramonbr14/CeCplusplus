#include <iostream>
#include <stdlib.h>
#include <stdio.h>
#include "LDE.C"

using namespace std;

int main (){
setlocale(LC_ALL,"Portuguese");
	system("cls");
	char L;
	L = 'S';
	lRM* liRM;
	while  (L=='S')
		{
			
			liRM = lcriar();
			system ("pause");
			liRM = finsercao(liRM,14);
			system ("pause");
			liRM = finsercao(liRM,5);
			system ("pause");
			liRM = finsercao(liRM,19);
			system ("pause");
			liRM = finsercao(liRM,88);
			system ("pause");
			
			
		//	printf("\n Teste 1 = %d", liRM->inf);
		//	printf("\n Teste 2 = %d", liRM->prx->inf);
		//	printf("\n Teste 3 = %d", liRM->prx->prx->inf);
		//	printf("\n Teste 4 = %d", liRM->prx->prx->prx->inf);
						
		/*	lRM* t = liRM;
			while(t->prx != NULL) {
				printf("\n Teste = %d", t->inf);
				t = t->prx;
			}
		*/	
			imprimirLDE(liRM);
			system ("pause");
			cout << "\n\nDeseja Repetir? ";
			cin >> L;
			L = toupper(L);	
	 	} 
	cout << "\n\nOBRIGADO E TENHA UM BOM DIA";
	cout << "\n\n\n\n";
	cout << "2016118970019 - RAMON DOS SANTOS SILVA - TADS";
	cout << "\n\n\n\n";
	system ("pause");
	return 0;
}
