#include <stdio.h>
#include <conio.h>
void main(){

  FILE *pontarq; 			/* define um ponteiro para a estrutura FILE */
  clrscr();

  /* abre o arquivo e faz o ponteiro apontar p/ o buffer */
  pontarq = fopen("teste.txt", "r");

  if(pontarq == NULL)
    printf("\nErro ao abrir o arquivo");

  else{
    printf("\nO arquivo foi aberto com sucesso!");
    /* fecha o arquivo */
    fclose(pontarq);
  }
  printf("\nPressione ENTER para sair! >>>");
  getchar();

} /* fecha o programa principal */